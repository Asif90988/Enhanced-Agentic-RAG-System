



import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../')))

"""
Document Repository for Unified Data Access

Provides a unified interface for accessing documents from both the database
and vector store, integrating structured and semantic search capabilities.
"""

import logging
from typing import Dict, Any, List, Optional, Tuple
import numpy as np
from datetime import datetime
from .database_manager import DatabaseManager
from .vector_store import VectorStore
from processing.nlp_pipeline import NLPPipeline

logger = logging.getLogger(__name__)

class DocumentRepository:
    """
    Unified document repository providing access to both structured and vector data.
    
    Features:
    - Unified document storage and retrieval
    - Hybrid search (structured + semantic)
    - Document synchronization between stores
    - Query optimization and caching
    - Batch operations for efficiency
    """
    
    def __init__(self):
        """Initialize document repository."""
        self.db_manager = DatabaseManager()
        self.vector_store = VectorStore()
        self.nlp_pipeline = NLPPipeline()
        
        logger.info("Document repository initialized")
    
    def store_document(self, structured_data: Dict[str, Any]) -> bool:
        """
        Store document in both database and vector store.
        
        Args:
            structured_data: Structured document data
            
        Returns:
            True if stored successfully
        """
        try:
            # Store in database
            db_success = self.db_manager.store_document(structured_data)
            if not db_success:
                logger.error("Failed to store document in database")
                return False
            
            # Prepare embeddings for vector store
            embeddings_data = self._prepare_embeddings_data(structured_data)
            
            # Store in vector store
            vector_success = self.vector_store.add_embeddings(embeddings_data)
            if not vector_success:
                logger.error("Failed to store document embeddings")
                # Note: In production, you might want to implement rollback
                return False
            
            logger.debug(f"Successfully stored document {structured_data['id']}")
            return True
            
        except Exception as e:
            logger.error(f"Error storing document: {e}")
            return False
    
    def _prepare_embeddings_data(self, structured_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Prepare embeddings data for vector store.
        
        Args:
            structured_data: Structured document data
            
        Returns:
            List of embedding data dictionaries
        """
        embeddings_data = []
        document_id = structured_data['id']
        embeddings = structured_data['embeddings']
        
        for chunk_data in embeddings['chunk_embeddings']:
            embedding_entry = {
                'chunk_id': chunk_data['chunk_id'],
                'document_id': document_id,
                'chunk_index': chunk_data['chunk_index'],
                'chunk_text': chunk_data['chunk_text'],
                'embedding_vector': chunk_data['embedding_vector'],
                'metadata': {
                    'source_type': structured_data['metadata'].get('source_type'),
                    'processed_at': structured_data['processing_info']['processed_at']
                }
            }
            embeddings_data.append(embedding_entry)
        
        return embeddings_data
    
    def get_document(self, document_id: str, include_embeddings: bool = False) -> Optional[Dict[str, Any]]:
        """
        Retrieve document by ID.
        
        Args:
            document_id: Document identifier
            include_embeddings: Whether to include embedding data
            
        Returns:
            Document data or None if not found
        """
        try:
            # Get document from database
            document = self.db_manager.get_document(document_id)
            if not document:
                return None
            
            # Add embeddings if requested
            if include_embeddings:
                document['embeddings'] = self._get_document_embeddings(document_id)
            
            return document
            
        except Exception as e:
            logger.error(f"Error retrieving document {document_id}: {e}")
            return None
    
    def _get_document_embeddings(self, document_id: str) -> List[Dict[str, Any]]:
        """Get all embeddings for a document."""
        try:
            # This is a simplified approach - in production, you might want
            # to implement a more efficient method to get all embeddings for a document
            embeddings = []
            
            # For now, we'll return empty list as FAISS doesn't easily support this
            # In a production system with Milvus, you could query by document_id
            
            return embeddings
            
        except Exception as e:
            logger.error(f"Error getting embeddings for document {document_id}: {e}")
            return []
    
    def search_documents(self, query: str, search_type: str = "hybrid", 
                        top_k: int = 10, source_filter: str = None) -> List[Dict[str, Any]]:
        """
        Search documents using various methods.
        
        Args:
            query: Search query
            search_type: Type of search ("text", "semantic", "hybrid")
            top_k: Number of results to return
            source_filter: Filter by source type
            
        Returns:
            List of matching documents with relevance scores
        """
        try:
            if search_type == "text":
                return self._search_text(query, top_k, source_filter)
            elif search_type == "semantic":
                return self._search_semantic(query, top_k, source_filter)
            elif search_type == "hybrid":
                return self._search_hybrid(query, top_k, source_filter)
            else:
                logger.warning(f"Unknown search type: {search_type}")
                return []
                
        except Exception as e:
            logger.error(f"Error searching documents: {e}")
            return []
    
    def _search_text(self, query: str, top_k: int, source_filter: str = None) -> List[Dict[str, Any]]:
        """Perform text-based search using database."""
        try:
            results = self.db_manager.search_documents(query, source_filter, top_k)
            
            # Add relevance scores (simplified)
            for result in results:
                result['relevance_score'] = self._calculate_text_relevance(query, result)
                result['search_type'] = 'text'
            
            return results
            
        except Exception as e:
            logger.error(f"Error in text search: {e}")
            return []
    
    def _search_semantic(self, query: str, top_k: int, source_filter: str = None) -> List[Dict[str, Any]]:
        """Perform semantic search using vector store."""
        try:
            # Generate query embedding
            query_embedding = self.nlp_pipeline.generate_embeddings([query])
            if query_embedding.size == 0:
                return []
            
            # Search similar chunks
            similar_chunks = self.vector_store.search_similar(
                query_embedding[0], top_k * 2, source_filter
            )
            
            # Group by document and get document details
            document_scores = {}
            for chunk in similar_chunks:
                doc_id = chunk['document_id']
                score = chunk['similarity_score']
                
                if doc_id not in document_scores:
                    document_scores[doc_id] = {
                        'max_score': score,
                        'avg_score': score,
                        'chunk_count': 1,
                        'chunks': [chunk]
                    }
                else:
                    document_scores[doc_id]['max_score'] = max(document_scores[doc_id]['max_score'], score)
                    document_scores[doc_id]['avg_score'] = (
                        (document_scores[doc_id]['avg_score'] * document_scores[doc_id]['chunk_count'] + score) /
                        (document_scores[doc_id]['chunk_count'] + 1)
                    )
                    document_scores[doc_id]['chunk_count'] += 1
                    document_scores[doc_id]['chunks'].append(chunk)
            
            # Get document details and create results
            results = []
            for doc_id, score_info in document_scores.items():
                document = self.db_manager.get_document(doc_id)
                if document:
                    document['relevance_score'] = score_info['max_score']
                    document['semantic_score'] = score_info['avg_score']
                    document['matching_chunks'] = score_info['chunks'][:3]  # Top 3 chunks
                    document['search_type'] = 'semantic'
                    results.append(document)
            
            # Sort by relevance score
            results.sort(key=lambda x: x['relevance_score'], reverse=True)
            
            return results[:top_k]
            
        except Exception as e:
            logger.error(f"Error in semantic search: {e}")
            return []
    
    def _search_hybrid(self, query: str, top_k: int, source_filter: str = None) -> List[Dict[str, Any]]:
        """Perform hybrid search combining text and semantic search."""
        try:
            # Get results from both search methods
            text_results = self._search_text(query, top_k, source_filter)
            semantic_results = self._search_semantic(query, top_k, source_filter)
            
            # Combine and deduplicate results
            combined_results = {}
            
            # Add text results
            for result in text_results:
                doc_id = result['id']
                result['text_score'] = result['relevance_score']
                result['semantic_score'] = 0.0
                combined_results[doc_id] = result
            
            # Add semantic results
            for result in semantic_results:
                doc_id = result['id']
                if doc_id in combined_results:
                    # Combine scores
                    combined_results[doc_id]['semantic_score'] = result['relevance_score']
                    combined_results[doc_id]['matching_chunks'] = result.get('matching_chunks', [])
                else:
                    result['text_score'] = 0.0
                    result['semantic_score'] = result['relevance_score']
                    combined_results[doc_id] = result
            
            # Calculate hybrid scores
            for result in combined_results.values():
                # Weighted combination of text and semantic scores
                text_weight = 0.3
                semantic_weight = 0.7
                
                result['relevance_score'] = (
                    text_weight * result['text_score'] +
                    semantic_weight * result['semantic_score']
                )
                result['search_type'] = 'hybrid'
            
            # Sort by hybrid score
            final_results = list(combined_results.values())
            final_results.sort(key=lambda x: x['relevance_score'], reverse=True)
            
            return final_results[:top_k]
            
        except Exception as e:
            logger.error(f"Error in hybrid search: {e}")
            return []
    
    def _calculate_text_relevance(self, query: str, document: Dict[str, Any]) -> float:
        """Calculate text relevance score (simplified)."""
        try:
            query_terms = query.lower().split()
            text_content = (
                document.get('title', '') + ' ' +
                document.get('content_text', '') + ' ' +
                document.get('content_summary', '')
            ).lower()
            
            # Simple term frequency scoring
            score = 0.0
            for term in query_terms:
                score += text_content.count(term)
            
            # Normalize by document length
            if len(text_content) > 0:
                score = score / len(text_content.split())
            
            return min(score * 10, 1.0)  # Scale and cap at 1.0
            
        except Exception as e:
            logger.error(f"Error calculating text relevance: {e}")
            return 0.0
    
    def get_recent_documents(self, limit: int = 10, source_type: str = None) -> List[Dict[str, Any]]:
        """
        Get recently processed documents.
        
        Args:
            limit: Maximum number of documents
            source_type: Filter by source type
            
        Returns:
            List of recent documents
        """
        try:
            return self.db_manager.get_recent_documents(limit, source_type)
        except Exception as e:
            logger.error(f"Error getting recent documents: {e}")
            return []
    
    def get_document_by_source(self, source_url: str, source_type: str) -> Optional[Dict[str, Any]]:
        """
        Get document by source URL and type.
        
        Args:
            source_url: Source URL or identifier
            source_type: Type of source
            
        Returns:
            Document data or None if not found
        """
        try:
            # Search for document with matching source metadata
            documents = self.db_manager.search_documents(source_url, source_type, 1)
            
            if documents:
                return documents[0]
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting document by source: {e}")
            return None
    
    def delete_document(self, document_id: str) -> bool:
        """
        Delete document from both database and vector store.
        
        Args:
            document_id: Document identifier
            
        Returns:
            True if deleted successfully
        """
        try:
            # Delete from vector store first
            vector_success = self.vector_store.delete_document_embeddings(document_id)
            
            # Delete from database (implement soft delete)
            # For now, we'll just mark as inactive
            # In production, you might want to implement proper deletion
            
            logger.info(f"Document {document_id} marked for deletion")
            return vector_success
            
        except Exception as e:
            logger.error(f"Error deleting document {document_id}: {e}")
            return False
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get repository statistics.
        
        Returns:
            Dictionary containing statistics from both stores
        """
        try:
            db_stats = self.db_manager.get_statistics()
            vector_stats = self.vector_store.get_statistics()
            
            return {
                'database': db_stats,
                'vector_store': vector_stats,
                'last_updated': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error getting statistics: {e}")
            return {}
    
    def health_check(self) -> Dict[str, Any]:
        """
        Perform health check on repository components.
        
        Returns:
            Health status of all components
        """
        try:
            health_status = {
                'database': 'healthy',
                'vector_store': 'healthy',
                'overall': 'healthy'
            }
            
            # Test database connection
            try:
                self.db_manager.get_statistics()
            except Exception as e:
                health_status['database'] = f'unhealthy: {e}'
                health_status['overall'] = 'degraded'
            
            # Test vector store
            try:
                self.vector_store.get_statistics()
            except Exception as e:
                health_status['vector_store'] = f'unhealthy: {e}'
                health_status['overall'] = 'degraded'
            
            return health_status
            
        except Exception as e:
            logger.error(f"Error in health check: {e}")
            return {'overall': 'unhealthy', 'error': str(e)}
    
    def close(self):
        """Close repository connections."""
        try:
            self.db_manager.close()
            self.vector_store.close()
            logger.info("Document repository connections closed")
        except Exception as e:
            logger.error(f"Error closing repository: {e}")

